# Creación de video

Este conjunto de archivos provee un ejemplo de manejo videográfico básico en el que se puede controlar el movimiento de un logo sobre el área visual de la pantalla.

## Archivos

### Generales

Estos archivos te serán útiles para cualquier manejo videográfico:

+ `Basys3.xdc`: archivo de restricciones con los *pins* de transmisión por **VGA** habilitados.
+ `Xelor.vhd`: archivo generador de señales de sincronización y cálculo de coordenadas.

### Específicos

+ `GraphicsProcessor.vhd`: a pesar de tener una estructura que está tejida específicamente para este proyecto de ejemplo, es posible reutilizar su estructura general para definir un componente que maneje el control de las señales de video.
+ `SM.vhd`: al igual que el anterior, este componente *Streaming Multiprocessor* puede servir como base, con ligeras modificaciones, para trabajar con cualquier otro proyecto.
+ `Su_logo.vhs`: componente controlador de la imagen específica del logo.
+ `su-logo.png-XXX.coe`: estos tres archivos contienen el vector de colores por componente del logo. Estos deben ser cargados utilizando el generador de **IP**
+ `movimiento_logo.suasm`: programa *assembly* para controlar el movimiento del logo en la pantalla utilizando los botones.

## Indicaciones

1. Reemplazar el archivo de restricciones antiguo con el provisto aquí.
2. Cargar todos los archivos `.vhd` a los recursos del proyecto para que Vivado® pueda reconocer los componentes utilizados.
3. Generar los bloques de memoria **IP** a través de la interfaz de Vivado®. Se debe generar un bloque por componente de color. **Importante:** la imagen del logo tiene dimensiones de 100x100 *pixeles*, además, deberás asignar el nombre `su_logo_COLOR` para cada bloque, reemplazando "COLOR" por el color que estás asignando.
4. Generar *bitstream* y cargar la arquitectura a la placa.
5. Cargar el programa en `movimiento_logo.suasm` utilizando *MinkiAssembler*.